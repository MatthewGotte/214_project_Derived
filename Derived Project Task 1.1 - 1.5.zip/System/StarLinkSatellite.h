
#ifndef __StarLinkSatellite_h__
#define __StarLinkSatellite_h__

#include "Satellite.h"

// class Satellite;
class StarLinkSatellite;

class StarLinkSatellite: public Satellite
{
};

#endif
