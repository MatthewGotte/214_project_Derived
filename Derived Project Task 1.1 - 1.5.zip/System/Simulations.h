
#ifndef __Simulations_h__
#define __Simulations_h__

class Simulations;

class Simulations
{
};

#endif
