
#ifndef __Satellite_h__
#define __Satellite_h__
#include "VacuumMerlinEngine.h"

class Satellite
{
    VacuumMerlinEngine* vacuumMerlinEngine;
};

#endif
