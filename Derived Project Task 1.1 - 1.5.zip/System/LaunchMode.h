
#ifndef __LaunchMode_h__
#define __LaunchMode_h__

class LaunchMode;

class LaunchMode
{
};

#endif
