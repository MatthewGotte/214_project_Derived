
#ifndef __TestMode_h__
#define __TestMode_h__

class TestMode;

class TestMode
{
};

#endif
