
#ifndef __MerlinEngine_h__
#define __MerlinEngine_h__

#include "Engine.h"

// class Engine;
class MerlinEngine;

class MerlinEngine: public Engine
{
};

#endif
