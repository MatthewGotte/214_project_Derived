
#ifndef __SpaceCraftFactory_h__
#define __SpaceCraftFactory_h__

class SpaceCraftFactory;

class SpaceCraftFactory
{
};

#endif
