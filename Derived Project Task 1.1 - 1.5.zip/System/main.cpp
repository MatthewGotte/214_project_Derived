#include <iostream>

using namespace std;

int main() {
    cout << "HELLO!" << endl;
    return 0;
}