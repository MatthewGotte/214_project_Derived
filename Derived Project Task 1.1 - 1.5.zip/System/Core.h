
#ifndef __Core_h__
#define __Core_h__

class Core;

class Core
{
};

#endif
