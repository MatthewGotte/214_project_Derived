
#ifndef __Cargo_h__
#define __Cargo_h__
#include <string>
#include "VectorOfCargo.h"
using namespace std;

class Cargo
{
public:
    Cargo();
    ~Cargo();
};

#endif
