
#ifndef __GroundMissionControl_h__
#define __GroundMissionControl_h__

class GroundMissionControl;

class GroundMissionControl
{
};

#endif
