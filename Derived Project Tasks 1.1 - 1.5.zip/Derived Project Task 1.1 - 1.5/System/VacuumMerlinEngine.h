
#ifndef __VacuumMerlinEngine_h__
#define __VacuumMerlinEngine_h__

#include "Engine.h"

// class Engine;
class VacuumMerlinEngine;

class VacuumMerlinEngine: public Engine
{
};

#endif
