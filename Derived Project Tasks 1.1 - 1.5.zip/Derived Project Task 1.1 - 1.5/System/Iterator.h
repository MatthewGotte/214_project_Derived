#ifndef PROJECT_ITERATOR_H
#define PROJECT_ITERATOR_H


class Iterator {

};


#endif //PROJECT_ITERATOR_H
