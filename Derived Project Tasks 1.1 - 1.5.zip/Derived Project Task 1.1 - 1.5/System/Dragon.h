
#ifndef __Dragon_h__
#define __Dragon_h__

#include "SpaceCraft.h"

// class SpaceCraft;
class Dragon;

class Dragon: public SpaceCraft
{
};

#endif
