
#ifndef __CrewDragon_h__
#define __CrewDragon_h__

#include "SpaceCraft.h"

#include "CargoCollection.h"
#include "HumanCollection.h"

// class SpaceCraft;
class CrewDragon;

class CrewDragon: public SpaceCraft
{
private:

public:
    CrewDragon();
};

#endif
