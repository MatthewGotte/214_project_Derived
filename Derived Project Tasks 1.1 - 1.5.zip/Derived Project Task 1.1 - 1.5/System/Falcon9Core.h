
#ifndef __Falcon9Core_h__
#define __Falcon9Core_h__

#include "Core.h"
#include "MerlinEngine.h"

// class Core;
class Falcon9Core;

class Falcon9Core: public Core
{
private:

};

#endif
